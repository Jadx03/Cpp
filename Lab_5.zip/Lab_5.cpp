// Name: Jainam Dhruva
// CS 215 - 009
// Lab-5


#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>

using namespace std;


//creating a data structure to store the number of votes of each candidate: in this case 3 candidates
struct precinct {

	int precinct_num;
	int numv_1;
	int numv_2;
	int numv_3;
};


//Creating an int for setting a constraint on the max size of the array introduced later to store each precinct's data 
const int max_size = 20;



int main() {


	// Reading the data from the given file--------------------------------------------------------------
	ifstream f;
	
	f.open("precincts.txt");

	string name1;
	string name2;
	string name3;
	int num_of_pre;

	if (f.fail()) {
		cout << "Failuire to open " << " precincts.txt";
		f.close();
		return 1;
	}


	getline(f, name1);
	getline(f, name2);
	getline(f, name3);
	f >> num_of_pre;

	//cout << name1 << endl;
	//cout << name2 << endl;
	//cout << name3 << endl;

	precinct arr1[max_size]; // arr1 = array used to store the precint number and votes 

	for (int i = 0; i < num_of_pre; i++) {
		f >> arr1[i].precinct_num >> arr1[i].numv_1 >> arr1[i].numv_2 >> arr1[i].numv_3;
		
	}
	//for (int i = 0; i < num_of_pre; i++) {
		//cout << arr1[i].precinct_num << " " << endl;// << arr1[i].numv_1 << " " <<  arr1[i].numv_2 <<" " << arr1[i].numv_3 << endl;
	//}

	f.close();
	// End of Reading the data from the given file-----------------------------------------------------------


	
	//sorting the precint numbers:
	for (int i = 0; i < num_of_pre; i++) {
		for (int j = 0; j < num_of_pre - 1; j++) {
			if (arr1[i].precinct_num < arr1[j].precinct_num) {
				precinct temp = arr1[i];
				arr1[i]  = arr1[j];
				arr1[j] = temp;
			}
		}
	}
	
	
	//for (int i = 0; i < num_of_pre; i++) {
		//cout << arr1[i].precinct_num << " " << arr1[i].numv_1 << " " <<  arr1[i].numv_2 <<" " << arr1[i].numv_3 << endl;
	//}



	//writing the sorted data into the new file--------------------------------------------------------------------
	ofstream g;
	g.open("results.txt");
	
	if (g.fail()) {
		cout << "Failuire to open " << " results.txt";
		g.close();
		return 2;
	}

	g << "-------------------------------------------------------" << endl;
	g << "                    Election Results                   " << endl;
	g << "-------------------------------------------------------" << endl;

	//g << "-------------------------------------------------------" << endl;

	g << "PRECINCT" << " "<< name1 << " " << name2 << "   " << name3 << endl;
	g << "--------" << " " << "---------------" << " " << "---------------" << " " << "---------------" << endl;
	
	for (int i = 0; i < num_of_pre; i++) {
		g << arr1[i].precinct_num << "     " << setw(16) << right << arr1[i].numv_1 << setw(16) << right << arr1[i].numv_2 << setw(16) << right << arr1[i].numv_3 <<endl;
	}

	int sum_numv_1 = 0;
	int sum_numv_2 = 0;
	int sum_numv_3 = 0;

	for (int i = 0; i < num_of_pre; i++) {
		sum_numv_1 = sum_numv_1 + arr1[i].numv_1;
		sum_numv_2 = sum_numv_2 + arr1[i].numv_2;
		sum_numv_3 = sum_numv_3 + arr1[i].numv_3;
	}

	g << "TOTALS" << "  " << setw(16) << right << sum_numv_1 << setw(16) << right << sum_numv_2 << setw(16) << right << sum_numv_3 << endl;

	//end of writing the sorted data into the new file--------------------------------------------------------------
	cout << "Election Data Procesed" << endl;

	system("pause");

	return 0;
}