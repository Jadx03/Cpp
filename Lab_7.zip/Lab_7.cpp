// Name: Jainam Dhruva
// Date: 2 April 2020
// CS 215 - 009
// Lab7 - A program that reads raw data from a file that contains an inventory of items. The items are
//        sorted by name, and the total value of the inventory calculated.A nice report is printed to a data file
//        including the sorted inventory data.
// Help -> I received help from no one.

#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>

using namespace std;
const int max = 10;

struct prod {
	double dollarAmt;
	int inStock;
	string name;
};


//-----------------------------------------------------------------
//					Read Inventory
//-----------------------------------------------------------------
void readInventory(prod temp[], int &numProd) {

	ifstream f;

	f.open("Inventory.txt");
	
	numProd = 0;

	if (f.fail()) {
		cout << "Unable to open Input file" << endl;
	}
	else {
		int i = 0;
		temp[0].dollarAmt = 0; 

		for (int i = 0; i < max; i++) {
			f >> temp[i].dollarAmt >> temp[i].inStock >> temp[i].name;
			if (temp[i].dollarAmt == -1) {
				cout << "Inventory Read" << endl;
				//f.close();
				
			}
			numProd = i + 1;
			
		}
		
		//cout << "Inventory Read" << endl;
	}


	f.close();
	
}	


//-----------------------------------------------------------------
//					Total Value
//-----------------------------------------------------------------
double totalVal(prod temp[], int strlen) {
	
	double sum = 0;
	
	for (int i = 0; i < strlen; i ++) {
		sum += temp[i].dollarAmt * temp[i].inStock;
	}
	return sum;
} 


//-----------------------------------------------------------------
//					Sort
//-----------------------------------------------------------------
void sort(prod temp[], int arr_len) {

	for (int i = 0; i < arr_len - 1; i++) {
		for (int j = i + 1; j < arr_len; j++) {
			if (temp[j].name > temp[i].name) {
				string local = temp[i].name;
				temp[i].name = temp[j].name;
				temp[j].name = local;
			}
		}
	}
	cout << "Inventory Sorted" << endl;
}


//-----------------------------------------------------------------
//					writeReport
//-----------------------------------------------------------------
void writeReport(prod temp[], int arr_len){


	ofstream g;

	g.open("report.txt");
	
	if (g.fail()) {
		cout << " Unable to open file. " << endl;
	}
	else {
		g << "+--------------------------------------------------+" << endl;
		g << "|               Current Inventory                  |" << endl;
		g << "+--------------------------------------------------+" << endl;
		g << "NAME                                 Price        # " << endl;
		g << "--------------------               ---------     ---" << endl;
		//Name(20) + (15) + Price(9) + (5) + Price(3)
		
		for (int i = 0; i < arr_len; i++) {
			g << setw(20) <<left << temp[i].name << "               " << "$" << setw(8) << right << temp[i].dollarAmt << "     " << setw(3) << right << temp[i].inStock << endl;
		}

		g << "----------------------------------------------------" << endl;
		//g << "--------------------               ---------     ---" << endl;

		int numprod = arr_len;
		double totalval = totalVal(temp, numprod);

		g << setw(30) << left << "Number of Products: " << numprod << endl;
		g << setw(30) << left << "Inventory total value: " << totalval << endl;
	}

	g.close();
	cout << "Report return to file. " << endl;
}


//-----------------------------------------------------------------
//					Main
//-----------------------------------------------------------------
void main() {
	
	prod MainArr[max];
	int ProdLen = 0;

	readInventory(MainArr,ProdLen);
	//cout << prod_len << endl;
	
	sort(MainArr, ProdLen);
	writeReport(MainArr, ProdLen);
	
	system("pause");
}

