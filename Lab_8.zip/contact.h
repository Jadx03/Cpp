//---------------------------------------------------
//			      Class Contact 
//---------------------------------------------------
//	       Describes the contact class
//---------------------------------------------------

#pragma once
#include <string>

class contact {

public:
	contact();
	void setName(std::string name1);
	void setNumber(std::string number1);

	std::string getName();
	std::string getNumber();
	void printContact();

private:
	std::string Name;
	std::string Number;

};