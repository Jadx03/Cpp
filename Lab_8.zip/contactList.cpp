#include <iostream>
#include <iomanip>
#include <string>
#include "contactList.h"
#include "contact.h"

using namespace std;

const int zero = 0;
//const int max = 5;
const int not_found = -1;

contactList::contactList() { Name_of_list = "NONE"; Num_of_contacts = zero; }

void contactList::setName_of_list(string nameAA) {
	Name_of_list = nameAA;
}

string contactList::getName_ofList() { return Name_of_list; }
int contactList::getNum_of_contacts() { return Num_of_contacts; }

void contactList::addContact(contact obj1) {
	if (Num_of_contacts < max) {
		Arr[Num_of_contacts] = obj1;
		Num_of_contacts++;
	}
	else {
		cout << "contactList::addContact(): max contacts exceeded!" << endl;
		std::string obj_name = obj1.getName();
		cout << obj_name << " not added!" << endl;
	}
}

int contactList::searchByName(string Name_to_search) {
	
	for (int i = zero; i < Num_of_contacts; i++) {
		if (Arr[i].getName() == Name_to_search) {
			return i;
		}
		else { return not_found; }
	}
}

contact contactList::getContact(int indexNum) {
	if (indexNum >= zero && indexNum < Num_of_contacts) {
		return Arr[indexNum];
	}
	else {
		contact emptyobj;
		return emptyobj;
	}
}

void contactList::print() {
	cout << "List name: " << Name_of_list << " (" << Num_of_contacts << "	contacts) " << endl;

	for (int i = zero; i < Num_of_contacts; i++) {
		Arr[i].printContact();
	}
}
