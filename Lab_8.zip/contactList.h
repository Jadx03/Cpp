//---------------------------------------------------
//			     Class Contact List
//---------------------------------------------------
//	 Describes a partial array of contact objects
//---------------------------------------------------

#pragma once
#include <string>
#include <iostream>
#include <iomanip>
# include "contact.h"

const int max = 5;

class contactList {
public:
	contactList();
	void setName_of_list(std::string nameAA);
	std::string getName_ofList();
	int getNum_of_contacts();
	void addContact(contact obj);
	int searchByName(std::string Name_to_search);
	contact getContact(int index_num);
	void print();

	
private:
	contact Arr[max];
	std::string Name_of_list;
	int Num_of_contacts;

};