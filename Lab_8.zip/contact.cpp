#include <iostream>
#include <iomanip>
#include "contact.h"

using namespace std;

contact::contact() { Name = "EMPTY"; Number = "";}

void contact::setName(string name1) {

    //string name;

    //if (cin.peek() == '\n') cin.ignore();
    //getline(cin, name);

    Name = name1;
}

void contact::setNumber(string number1) {
    Number = number1;
}

string contact::getName() { return Name; }

string contact::getNumber() { return Number; }



void contact::printContact() {
    cout <<setw(12) <<left<< Number << " " << Name << endl;
}



